<div class="col-md-3 col-sm-12 blog_sidebar">
      	<?php dynamic_sidebar(); ?>
      </div>