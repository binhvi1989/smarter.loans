<?php

/* Deregister jQuery included with WordPress */
if(!is_admin()) {
	/**************** IF CUFON IS ENABLED, ENQUEUE SCRIPTS ****/
	if(!is_home()) {
		wp_enqueue_script('jquery.prettyPhoto', CADEN_JS . '/jquery.prettyPhoto.js');
		wp_enqueue_script('slides.min.jquery', CADEN_JS . '/slides.min.jquery.js');
	}	
	
}

?>